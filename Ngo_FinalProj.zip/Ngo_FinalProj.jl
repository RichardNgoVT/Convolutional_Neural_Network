using Distributions, Random, Plots, HDF5, Statistics, LinearAlgebra
function test(layersK,kernels,kernBias,inputs,layersN, layerEnterHL, layersHL, layerLastHL, A, target, width, height, flatSize) 
println("Testing")
	B = size(A)[1]
	inputsEnterHL = zeros(flatSize, B)
	
	inputsHL = zeros(1)
	if(layersN[2]>2)
		inputsHL = zeros(layersN[1]+1, B, layersN[2]-2)
	end
	
	
	inputsLastHL = zeros(layersN[1]+1, B)
	t = target'
	convout=zeros(1)
	imgWn = width
	imgHn = height
	if size(layersK)[1] == 0
		inputsEnterHL = [ones(1,B);A']
		#t = target[sample,:]
	else
		for b = 1:B
		if(b%100 == 0)
			println("Testing Img #: $(b)")
		end
			imgW = width
			imgH = height

			#initialize start
			convout = A[b,:]

			#forward prop
			
			for l = 0:size(layersK)[1]
			#println("Layer: $(l)")
			if l > 0
				if layersK[l,1]>0
				
					convout = zeros(size(inputs[l])[1],layersK[l,3])
					
					for i = 1:layersK[l,3]
					
						convout[:,i]=sum(permutedims(inputs[l], [3, 2, 1]).*kernels[l][:,i,:]',dims = [1,2]).+kernBias[l][i]
						#return convout[:,:], sum(permutedims(inputs[l], [3, 2, 1]).*kernels[l][:,i,:]',dims = [1,2]), i
					end
				
					#relu
					#convout = max.(convout,0)
					convout[convout .< 0] .*= .001
				else
					#maxpool
					(convout,poolloc) = findmax(inputs[l], dims = 2)
					convout = permutedims(convout, [1, 3, 2])[:,:]
					
					cleaner=zeros(size(inputs[l]))

					for i in poolloc
						#cleaner[i[1],i[2],i[3]] = inputs[l][i[1],i[2],i[3]]
						cleaner[i[1],i[2],i[3]] = 1
					end

					inputs[l].*= cleaner#rid of irreleavent numbers
				end
			end

				#input to next layer
				if l<size(layersK)[1]
					if layersK[l+1,1]>0 

						kerSize = layersK[l+1,1]

						imgHn=imgH-(kerSize-1)
						imgWn=imgW-(kerSize-1)
						#println("before")
						for i = 1:size(inputs[l+1])[1]
							xpos = ((i-1)%imgWn)+1
							ypos = floor(Int,(i-1)/imgWn)
							for j = 0:kerSize-1
								inputs[l+1][i,(kerSize*j)+1:(kerSize*(j+1)),:] = convout[(ypos+j)*(imgW)+xpos:(ypos+j)*(imgW)+xpos+kerSize-1,:]
							end
						end
						#println("after")
						else#next is pooling

						imgHn=floor(Int,imgH/layersK[l+1,2])
						imgWn=floor(Int,imgW/layersK[l+1,3])

						for i = 1:size(inputs[l+1])[1]
							xpos = ((i-1)%imgWn)*layersK[l+1,3]+1
							ypos = floor(Int,(i-1)/imgWn)*layersK[l+1,2]
							
							for j = 0:layersK[l+1,2]-1
							
							#return(inputs[l+1], convout, xpos, ypos, imgHn,imgWn,imgH,imgW)
								inputs[l+1][i,(layersK[l+1,3]*j)+1:(layersK[l+1,3]*(j+1)),:] = convout[(ypos+j)*(imgW)+xpos:(ypos+j)*(imgW)+xpos+layersK[l+1,3]-1,:]
							end
						end
					end
					imgH=imgHn
					imgW=imgWn
				end
			end
			
			inputsEnterHL[:,b] = [1;convout[:]]
			#t[:,b] = target[sample[b],:]
			
		end
		#convShape = size(convout)
		
	end
	
	
	 
	##########
	#connect to Neural layer
	#println("Neural Network")
	# forward propagate
	
	if(layersN[2]<3)
		inputsLastHL=[ones(1,B);(exp.((layerEnterHL*inputsEnterHL).*-1).+1).^(-1)]
	else
		inputsHL[:,:,1]=[ones(1,B);(exp.((layerEnterHL*inputsEnterHL).*-1).+1).^(-1)]
		
		
		for l = 1:layersN[2]-2-1
			inputsHL[:,:,l+1]=[ones(1,B);(exp.((layersHL[:,:,l]*inputsHL[:,:,l]).*-1).+1).^(-1)]
		end
		
		inputsLastHL=[ones(1,B);(exp.((layersHL[:,:,size(layersHL)[3]]*inputsHL[:,:,size(layersHL)[3]]).*-1).+1).^(-1)]
	end
	outHL = (exp.((layerLastHL*inputsLastHL).*-1).+1).^(-1)
	
	
	# end forward propagate
	view = round.(outHL,RoundNearestTiesUp).-t
	viewAns = Int.(-min.(view,0))
	viewGuess = Int.(max.(view,0))
	count = sum(viewAns)
	rate = count/size(t)[2]
	
	err = sum((outHL.-t)*(outHL'.-t').*I(size(t)[1]))

	return err, viewAns, viewGuess, rate
end




function FinalProj(layersK, layersN)
##########
#Set Up


	data = h5read("mnist.h5", "train")
	#found = findall(z->z==0x00 || z==0x01 || z==0x02, data["labels"])
	#input = data["images"][:,:,found[:]]
	#targetsee = data["labels"][found[:]]
    
	input = data["images"]
	targetsee = data["labels"]
	
	target = zeros(size(targetsee)[1],10)
	
	for i = 1:size(targetsee)[1]
	target[i,targetsee[i]+1] = 1
	end
	
	#input, target = draw(300)

	#input = input[:,:,1:300]
	#target = target[1:300,:]
	
	
	height = size(input)[1]
	width = size(input)[2]
    imgs = size(input)[3]	
	#N = width*height+1
	
	#A = zeros(imgs, width*height+1)
	A = zeros(imgs, width*height)
	#t = zeros(imgs)
	count = 1
	for i = 1:imgs
		for h = 1:height
			for w = 1:width
				#A[i, w+(h-1)*width+1] = data[h,w,i]
				A[i, w+(h-1)*width] = input[h,w,i]
			end
		end
	end			
	
	#meanA = mean(A)
	#stdA = std(A)
	#A = A/stdA .- meanA
	#A = A/255
	#hat = zeros(imgs)
	#hat.+=1
	#A = [hat';A']'

##########
#Initialize layersK
#Neural network



    N = size(target)[1]

	
    
    # number to hold out
    Nhold = round(Int64, N*.1)

    # number in training set
    Ntrain = N - Nhold

    # create indices
    idx = shuffle(1:N)

    trainidx = idx[1:Ntrain]
    testidx = idx[(Ntrain+1):N]

    println("$(length(trainidx)) training samples")
    println("$(length(testidx)) validation samples")
    
    # number of hidden nodes
    #M = 4096#1024

    # batch size
    #B = floor(Int,Ntrain/2)#32
	
	B = 200
    
	testBatch = 1000
	
	checkFreq = 20
	batchstate = B+1
	window = 8
	error = []
    
    stop = false
	
	
	t = zeros(size(target)[2],B)
	
	
	step = 1/1000#(1/B)*(1/1000)
	substep = 0
	steplim = 3
	trainLim = 0
	
	###
	alpha = .0001
	B1 = .9
	B2 = .999
	ee = 10^(-8)
	###
	
#####


imgW = width
imgH = height
imgD = 1
kernels = Vector{Array{Float32}}()
kernGrad = Vector{Array{Float32}}()
kernBias = Vector{Array{Float32}}()
kernBiasGrad = Vector{Array{Float32}}()
ins = Vector{Array{Float32}}()
inputs = Vector{Vector{Array{Float32}}}()

for l = 1:size(layersK)[1]
	if layersK[l,1]>0
		push!(kernels,0.05*randn(layersK[l,1]*layersK[l,2],layersK[l,3],imgD))
		push!(kernGrad,zeros(layersK[l,1]*layersK[l,2],layersK[l,3],imgD))
		
		push!(kernBias,0.05*randn(layersK[l,3]))
		push!(kernBiasGrad,zeros(layersK[l,3]))
		
		kerPad = (layersK[l,1]-1)
		imgH-=kerPad
		imgW-=kerPad
		push!(ins,zeros(imgH*imgW,layersK[l,1]*layersK[l,2],imgD))
		imgD = layersK[l,3]
	else#pool
		push!(kernels,zeros(1))
		push!(kernGrad,zeros(1))
		push!(kernBias,zeros(1))
		push!(kernBiasGrad,zeros(1))
		if(imgH%layersK[l,2]!=0 || imgW%layersK[l,3]!=0)
			println("bad pool fit at layer: $(l)")
			println("old pool dims: $(layersK[l,2])x$(layersK[l,3])")
			while imgH%layersK[l,2]!=0
			layersK[l,2]-=1
			end
			while imgW%layersK[l,3]!=0
			layersK[l,3]-=1
			end
			println("new pool dims: $(layersK[l,2])x$(layersK[l,3])")
			println()
		end
		
		layersK[l,2]-=imgH%layersK[l,2]
		layersK[l,3]-=imgW%layersK[l,3]
		imgH=floor(Int,imgH/layersK[l,2])
		imgW=floor(Int,imgW/layersK[l,3])
		push!(ins,zeros(imgH*imgW,layersK[l,2]*layersK[l,3],imgD))
	end
end

flatSize = imgH*imgW*imgD+1
imgHed = imgH
imgWed = imgW


#Neural Network Initialization

inputsEnterHL = zeros(flatSize, B)

layerEnterHL = 0.05*randn(layersN[1],flatSize)

mtEHL = zeros(size(layerEnterHL))
vtEHL = zeros(size(layerEnterHL))

inputsHL = zeros(1)

layersHL = zeros(1)

gradHL = zeros(1)

mtHL = zeros(1)
vtHL = zeros(1)

if(layersN[2]>2)
inputsHL = zeros(layersN[1]+1, B, layersN[2]-2)

layersHL = 0.05*randn(layersN[1], layersN[1]+1, layersN[2]-2)

gradHL = zeros(size(layersHL))

mtHL = zeros(size(layersHL))
vtHL = zeros(size(layersHL))
end


inputsLastHL = zeros(layersN[1]+1, B)

layerLastHL = 0.05*randn(10, layersN[1]+1)

mtLHL = zeros(size(layerLastHL))
vtLHL = zeros(size(layerLastHL))

outHL = zeros(10,B)

if(layersN[2]>2)
	numweights = prod(size(layerEnterHL)) + prod(size(layersHL)) + prod(size(layerLastHL))
else
	numweights = prod(size(layerEnterHL)) + prod(size(layerLastHL))
end
for l = 1:size(layersK)[1]
	if layersK[l,1]>0
		numweights+=prod(size(kernels[l]))
		numweights+=prod(size(kernBias[l]))
	end
end
	
println("$(numweights) weights")
#input transitioner

x = zeros(B,flatSize)

for b = 1:B
	push!(inputs,deepcopy(ins))
end

mt = deepcopy(kernGrad)
vt = deepcopy(kernGrad)

mtKB = deepcopy(kernBiasGrad)
vtKB = deepcopy(kernBiasGrad)

sampleHold=trainidx[shuffle(1:Ntrain)]
sampleSelect = 0

##########
#start convolution forward propagation
trainCount = 0

errCurr = 0
errCount = 0
errRate = 0
epoch = 0

while(!stop||epoch==0)
println("Training Iteration: $(trainCount)")

	println("Forward Convolution")
	convout=zeros(1)
	
	if(B*(sampleSelect+1)>Ntrain)#all samples covered efficiently
		sampleHold=trainidx[shuffle(1:Ntrain)]
		sampleSelect = 0
		epoch+=1
	end
	sample = sampleHold[B*sampleSelect+1:B*(sampleSelect+1)]
	sampleSelect+=1
	imgWn = width
	imgHn = height
	
	if size(layersK)[1] == 0
		inputsEnterHL = [ones(1,B);A[sample,:]']
		t = target[sample,:]'
	else
		for b = 1:B
		if(b%batchstate == 0)
			println("Batch Img #: $(b)")
		end
			imgW = width
			imgH = height

			#initialize start
			convout = A[sample[b],:]

			#forward prop
			
			for l = 0:size(layersK)[1]
			#println("Layer: $(l)")
			if l > 0
				if layersK[l,1]>0
				
					convout = zeros(size(inputs[b][l])[1],layersK[l,3])
					
					for i = 1:layersK[l,3]
					
						convout[:,i]=sum(permutedims(inputs[b][l], [3, 2, 1]).*kernels[l][:,i,:]',dims = [1,2]).+kernBias[l][i]
						#return convout[:,:], sum(permutedims(inputs[b][l], [3, 2, 1]).*kernels[l][:,i,:]',dims = [1,2]), i
					end
				
					#relu
					#convout = max.(convout,0)
					convout[convout .< 0] .*= .001
				else
					#maxpool
					(convout,poolloc) = findmax(inputs[b][l], dims = 2)
					convout = permutedims(convout, [1, 3, 2])[:,:]
					
					cleaner=zeros(size(inputs[b][l]))

					for i in poolloc
						#cleaner[i[1],i[2],i[3]] = inputs[b][l][i[1],i[2],i[3]]
						cleaner[i[1],i[2],i[3]] = 1
					end

					inputs[b][l].*= cleaner#rid of irreleavent numbers
				end
			end

				#input to next layer
				if l<size(layersK)[1]
					if layersK[l+1,1]>0 

						kerSize = layersK[l+1,1]

						imgHn=imgH-(kerSize-1)
						imgWn=imgW-(kerSize-1)
						#println("before")
						for i = 1:size(inputs[b][l+1])[1]
							xpos = ((i-1)%imgWn)+1
							ypos = floor(Int,(i-1)/imgWn)
							for j = 0:kerSize-1
								inputs[b][l+1][i,(kerSize*j)+1:(kerSize*(j+1)),:] = convout[(ypos+j)*(imgW)+xpos:(ypos+j)*(imgW)+xpos+kerSize-1,:]
							end
						end
						#println("after")
						else#next is pooling

						imgHn=floor(Int,imgH/layersK[l+1,2])
						imgWn=floor(Int,imgW/layersK[l+1,3])

						for i = 1:size(inputs[b][l+1])[1]
							xpos = ((i-1)%imgWn)*layersK[l+1,3]+1
							ypos = floor(Int,(i-1)/imgWn)*layersK[l+1,2]
							
							for j = 0:layersK[l+1,2]-1
							
							#return(inputs[b][l+1], convout, xpos, ypos, imgHn,imgWn,imgH,imgW)
								inputs[b][l+1][i,(layersK[l+1,3]*j)+1:(layersK[l+1,3]*(j+1)),:] = convout[(ypos+j)*(imgW)+xpos:(ypos+j)*(imgW)+xpos+layersK[l+1,3]-1,:]
							end
						end
					end
					imgH=imgHn
					imgW=imgWn
				end
			end
			
			inputsEnterHL[:,b] = [1;convout[:]]
			t[:,b] = target[sample[b],:]
			
		end
		convShape = size(convout)
		
	end
	
	
	 
	##########
	#connect to Neural layer
	println("Neural Network")
	# forward propagate
	
	if(layersN[2]<3)
		inputsLastHL=[ones(1,B);(exp.((layerEnterHL*inputsEnterHL).*-1).+1).^(-1)]
	else
		inputsHL[:,:,1]=[ones(1,B);(exp.((layerEnterHL*inputsEnterHL).*-1).+1).^(-1)]
		
		
		for l = 1:layersN[2]-2-1
			inputsHL[:,:,l+1]=[ones(1,B);(exp.((layersHL[:,:,l]*inputsHL[:,:,l]).*-1).+1).^(-1)]
		end
		
		inputsLastHL=[ones(1,B);(exp.((layersHL[:,:,layersN[2]-2]*inputsHL[:,:,layersN[2]-2]).*-1).+1).^(-1)]
	end
	outHL = (exp.((layerLastHL*inputsLastHL).*-1).+1).^(-1)
	
	# end forward propagate
	view = round.(outHL,RoundNearestTiesUp).-t
	viewAns = Int.(-min.(view,0))
	viewGuess = Int.(max.(view,0))
	count = sum(viewAns)
	rate = count/size(t)[2]
	
	err = sum((outHL.-t)*(outHL'.-t').*I(size(t)[1]))
	
	println("Batch Set Error = $(err)")
	println("Batch Images Inccorectly Classified: $(count) out of $(size(t)[2])")
	println("Classified  Wrong 0:$(sum(viewAns[1,:]))/$(Int(sum(t[1,:]))), 1:$(sum(viewAns[2,:]))/$(Int(sum(t[2,:]))), 2:$(sum(viewAns[3,:]))/$(Int(sum(t[3,:]))), 3:$(sum(viewAns[4,:]))/$(Int(sum(t[4,:]))), 4:$(sum(viewAns[5,:]))/$(Int(sum(t[5,:]))), 5:$(sum(viewAns[6,:]))/$(Int(sum(t[6,:]))), 6:$(sum(viewAns[7,:]))/$(Int(sum(t[7,:]))), 7:$(sum(viewAns[8,:]))/$(Int(sum(t[8,:]))), 8:$(sum(viewAns[9,:]))/$(Int(sum(t[9,:]))), 9:$(sum(viewAns[10,:]))/$(Int(sum(t[10,:])))")
	println("Wrong Guesses 0:$(sum(viewGuess[1,:])), 1:$(sum(viewGuess[2,:])), 2:$(sum(viewGuess[3,:])), 3:$(sum(viewGuess[4,:])), 4:$(sum(viewGuess[5,:])), 5:$(sum(viewGuess[6,:])), 6:$(sum(viewGuess[7,:])), 7:$(sum(viewGuess[8,:])), 8:$(sum(viewGuess[9,:])), 9:$(sum(viewGuess[10,:]))")
	println("Batch Set Error Rate = $(rate)")
	
	# output error
	
	deltaOut = outHL-t
	deltaIn = outHL.*(-outHL.+1)
	
	gradLastHL = (deltaOut.*deltaIn)*inputsLastHL'#y
	gradLastHL[:,1] = (deltaOut*inputsLastHL')[:,1]
	#was not in hw solutions...
	#deltaOut = layerLastHL[:,2:layersN[1]+1]'*(deltaOut.*deltaIn)
	deltaOut = layerLastHL[:,2:layersN[1]+1]'*(deltaOut)
	deltaIn = (inputsLastHL.*(-inputsLastHL.+1))[2:layersN[1]+1,:]
	if(layersN[2]>2)
		for l = layersN[2]-2:-1:1#X

			gradHL[:,:,l] = (deltaOut.*deltaIn)*inputsHL[:,:,l]'
			gradHL[:,1,l] = (deltaOut*inputsHL[:,:,l]')[:,1]
			
			deltaOut = layersHL[:,2:layersN[1]+1,l]'*(deltaOut.*deltaIn)
			#deltaOut = layersHL[:,2:layersN[1]+1,l]'*(deltaOut)
			deltaIn = (inputsHL[:,:,l].*(-inputsHL[:,:,l].+1))[2:layersN[1]+1,:]
			
		end
	end
	
	gradEnterHL = (deltaOut.*deltaIn)*inputsEnterHL'
	gradEnterHL[:,1] = (deltaOut*inputsEnterHL')[:,1]

	deltaOut = layerEnterHL[:,2:flatSize]'*(deltaOut.*deltaIn)
	#deltaOut = layerEnterHL[:,2:flatSize]'*(deltaOut)
	#deltaIn = (inputsEnterHL[:,:,1].*(-inputsEnterHL.+1))[2:flatSize,:]
	

	##########
	#start convolution backpropagation
	println("Backwards Convolution")
	#return inputs,x,convShape,kernels,weight1,weight2,grad1,grad2
	errNext = zeros(1)
	if size(layersK)[1] > 0
		for b = 1:B
		if(b%batchstate == 0)
			println("Batch Img #: $(b)")
		end
			errHold = reshape(deltaOut[:,b], convShape)
			imgH = imgHed
			imgW = imgWed
			for l = size(layersK)[1]:-1:1
				#println("Layer:$(l), Batch:$(b)")
				if layersK[l,1]>0
					for i = 1:size(kernels[l])[2]

						inhold=inputs[b][l].*errHold[:,i]
						kernBiasGrad[l][i]+=sum(errHold[:,i])
						#inhold[:,:,:].*=kernels[l][:,i]'

						#for j = 1:size(kernels[l])[1]
						#kernGrad[j,i,:] =  sum(inhold[:,j,:],dims=1)
						#end
						kernGrad[l][:,i,:] +=  permutedims(sum(inhold,dims=1),[2,3,1])#used to be dims=[1,3]
						
					end

					#get relavent pos at each dy
					errform = zeros(size(kernels[l])[1],size(kernels[l])[2])
					outhold = zeros(size(kernels[l])[1],size(kernels[l])[2],size(kernels[l])[3])
					kerSize = layersK[l,1]
					kerPad = kerSize-1
					imgHn=imgH+kerPad
					imgWn=imgW+kerPad
					#imgH+=kerPad
					#imgW+=kerPad
					
					errNext = zeros(imgHn*imgWn,size(inputs[b][l])[3])
					
					for i = 1:(imgHn)*(imgWn)
						xpos = (i-1)%(imgWn)+1-kerPad
						ypos = floor(Int,(i-1)/(imgWn))-kerPad

						voidL = min(xpos-1,0)
						voidR = max(xpos+kerPad-(imgW),0)
						voidU = min(ypos,0)
						voidD = max(ypos+1+kerPad-(imgH),0)
						
						#println("X:$(xpos) Y:$(ypos) L:$(voidL) R:$(voidR) U:$(voidU) D:$(voidD)")
						
						for j = -voidU:kerSize-1-voidD
						#println(j)
							errform[size(kernels[l])[1]-((kerSize*j)-voidL):-1:size(kernels[l])[1]-(kerSize*(j+1)-voidR)+1,:] = errHold[(ypos+j)*(imgW)+xpos-voidL:(ypos+j)*(imgW)+xpos+kerSize-1-voidR,:]
							#inputs[b][l][i,(kerSize*j)+1-voidL:(kerSize*(j+1))-voidR,:] = convout[(ypos+j)*(imgW)+xpos-voidL:(ypos+j)*(imgW)+xpos+kerSize-1-voidR,:]
						end
						outhold=kernels[l].*errform
						
						#if i== 600
						#println("$(imgH) $(imgW) $(kerSize) $(kerPad)")
						#return errHold,errform,outhold,kernels[l],errNext,sum(outhold, dims = [1,2])
						#end
						errNext[i,:] = sum(outhold, dims = [1,2])

					end
					#return errHold,errform,outhold,kernels[l],errNext,sum(outhold, dims = [1,2])
					
					
				else
					#pooling, just pass grad onto where values were maxes, rest is 0, thats all
					imgHn=imgH*layersK[l,2]
					imgWn=imgW*layersK[l,3]
					errNext = zeros(imgHn*imgWn,size(inputs[b][l])[3])
					errHold = permutedims(errHold[:,:,:], [1, 3, 2])
					inputs[b][l].*=errHold
					#return inputs[b][l], errHold
					
					for i = 1:size(inputs[b][l])[1]
							xpos = ((i-1)%imgW)*layersK[l,3]+1
							ypos = floor(Int,(i-1)/imgW)*layersK[l,2]
							for j = 0:layersK[l,2]-1
							errNext[(ypos+j)*(imgWn)+xpos:(ypos+j)*(imgWn)+xpos+layersK[l,3]-1,:]=inputs[b][l][i,(layersK[l,3]*j)+1:(layersK[l,3]*(j+1)),:]
						end 
					end
				end
				errHold=errNext
				imgH=imgHn
				imgW=imgWn

			end
			#println("LOOP COMPLETE!")
		end
	end
	#update weights
	at = alpha*((1-B2^(trainCount+1))^(1/2))/(1-B1^(trainCount+1))
	
	for l = 1:size(layersK)[1]
		if layersK[l,1]>0
			mt[l] = B1*mt[l]+(1-B1)*(kernGrad[l])
			vt[l] = B2*vt[l]+(1-B2)*(kernGrad[l].*kernGrad[l])
			kernels[l]-=at*mt[l]./(vt[l].^(1/2).+ee)
			kernGrad[l]*=0
			#kernels[l].+=kernGrad[l]*step
			
			mtKB[l] = B1*mtKB[l]+(1-B1)*(kernBiasGrad[l])
			vtKB[l] = B2*vtKB[l]+(1-B2)*(kernBiasGrad[l].*kernBiasGrad[l])
			kernBias[l]-=at*mtKB[l]./(vtKB[l].^(1/2).+ee)
			kernBiasGrad[l]*=0
		end
	end
	
	if(layersN[2]>2)
		mtHL = B1*mtHL+(1-B1)*(gradHL)
		vtHL = B2*vtHL+(1-B2)*(gradHL.*gradHL)
		layersHL -=at*mtHL./(vtHL.^(1/2).+ee)
		
		gradHL*=0
	end
	
	mtEHL = B1*mtEHL+(1-B1)*(gradEnterHL)
	vtEHL = B2*vtEHL+(1-B2)*(gradEnterHL.*gradEnterHL)
	layerEnterHL -=at*mtEHL./(vtEHL.^(1/2).+ee)
	
	mtLHL = B1*mtLHL+(1-B1)*(gradLastHL)
	vtLHL = B2*vtLHL+(1-B2)*(gradLastHL.*gradLastHL)
	layerLastHL -=at*mtLHL./(vtLHL.^(1/2).+ee)
	
	
	if trainCount%checkFreq == 0
		#return testidx[shuffle(1:(N-Ntrain))][1:B],trainidx[shuffle(1:Ntrain)][1:B]
		testSample = testidx[shuffle(1:(N-Ntrain))][1:testBatch]
		errCurr, errAns, errGuess, errRate = test(layersK,kernels,kernBias,ins,layersN, layerEnterHL, layersHL, layerLastHL, A[testSample,:],target[testSample,:],width,height,flatSize)
		push!(error, errCurr)
		println("Holdout Set Error = $(errCurr)")
		println("Holdout Images Inccorectly Classified: $(sum(errAns)) out of $(size(testSample)[1])")
		println("Classified  Wrong 0:$(sum(errAns[1,:]))/$(Int(sum(target[testSample,:][:,1]))), 1:$(sum(errAns[2,:]))/$(Int(sum(target[testSample,:][:,2]))), 2:$(sum(errAns[3,:]))/$(Int(sum(target[testSample,:][:,3]))), 3:$(sum(errAns[4,:]))/$(Int(sum(target[testSample,:][:,4]))), 4:$(sum(errAns[5,:]))/$(Int(sum(target[testSample,:][:,5]))), 5:$(sum(errAns[6,:]))/$(Int(sum(target[testSample,:][:,6]))), 6:$(sum(errAns[7,:]))/$(Int(sum(target[testSample,:][:,7]))), 7:$(sum(errAns[8,:]))/$(Int(sum(target[testSample,:][:,8]))), 8:$(sum(errAns[9,:]))/$(Int(sum(target[testSample,:][:,9]))), 9:$(sum(errAns[10,:]))/$(Int(sum(target[testSample,:][:,10])))")
		println("Wrong Guesses 0:$(sum(errGuess[1,:])), 1:$(sum(errGuess[2,:])), 2:$(sum(errGuess[3,:])), 3:$(sum(errGuess[4,:])), 4:$(sum(errGuess[5,:])), 5:$(sum(errGuess[6,:])), 6:$(sum(errGuess[7,:])), 7:$(sum(errGuess[8,:])), 8:$(sum(errGuess[9,:])), 9:$(sum(errGuess[10,:]))")
		println("Holdout Set Error Rate = $(errRate)")
		

		
		if length(error) > 2*window+1
		
			runningerror = error[(end-window):end]

			mean1 = mean(runningerror)
			mean2 = mean(error[(end-2*window):(end-window)])
			
			println("Mean error over last $(window) iterations $(mean1), previous $(window) $(mean2)")
			stop = mean1 > mean2
		end
	end
		
	trainCount += 1
	if(trainCount == trainLim)
		stop = true
	end
	if(errRate<.01)
		stop = true
	end
	println()
end#END of while loop

	errHist = zeros(length(error))
	for i = 1:length(error)
		errHist[i]=error[i]
	end
	
	data2 = h5read("mnist.h5", "test")
	
	#found2 = findall(z->z==0x00 || z==0x01 || z==0x02, data2["labels"])
	#input2 = data2["images"][:,:,found2[:]]
	#targetsee2 = data2["labels"][found2[:]]
	
    input2 = data2["images"]
	targetsee2 = data2["labels"]
	
	target2 = zeros(size(targetsee2)[1],10)
	
	for i = 1:size(targetsee2)[1]
	target2[i,targetsee2[i]+1] = 1
	end
	
	#input, target = draw(300)

	#input = input[:,:,1:300]
	#target = target[1:300,:]
	
	
	height2 = size(input2)[1]
	width2 = size(input2)[2]
    imgs2 = size(input2)[3]	
	#N = width*height+1
	
	#A = zeros(imgs, width*height+1)
	A2 = zeros(imgs2, width2*height2)
	#t = zeros(imgs)
	count = 1
	for i = 1:imgs2
		for h = 1:height2
			for w = 1:width2
				#A[i, w+(h-1)*width2+1] = data[h,w,i]
				A2[i, w+(h-1)*width2] = input2[h,w,i]
			end
		end
	end			
	
	errCurrT,errAnsT,errGuessT,errRateT = test(layersK,kernels,kernBias,ins,layersN, layerEnterHL, layersHL, layerLastHL,A2,target2,width2,height2,flatSize)
	
	println("Test Set Error = $(errCurrT)")
	println("Test Images Inccorectly Classified: $(sum(errAnsT)) out of $(size(target2)[1])")
	println("Classified  Wrong 0:$(sum(errAnsT[1,:]))/$(Int(sum(target2[:,1]))), 1:$(sum(errAnsT[2,:]))/$(Int(sum(target2[:,2]))), 2:$(sum(errAnsT[3,:]))/$(Int(sum(target2[:,3]))), 3:$(sum(errAnsT[4,:]))/$(Int(sum(target2[:,4]))), 4:$(sum(errAnsT[5,:]))/$(Int(sum(target2[:,5]))), 5:$(sum(errAnsT[6,:]))/$(Int(sum(target2[:,6]))), 6:$(sum(errAnsT[7,:]))/$(Int(sum(target2[:,7]))), 7:$(sum(errAnsT[8,:]))/$(Int(sum(target2[:,8]))), 8:$(sum(errAnsT[9,:]))/$(Int(sum(target2[:,9]))), 9:$(sum(errAnsT[10,:]))/$(Int(sum(target2[:,10])))")
	println("Wrong Guesses 0:$(sum(errGuessT[1,:])), 1:$(sum(errGuessT[2,:])), 2:$(sum(errGuessT[3,:])), 3:$(sum(errGuessT[4,:])), 4:$(sum(errGuessT[5,:])), 5:$(sum(errGuessT[6,:])), 6:$(sum(errGuessT[7,:])), 7:$(sum(errGuessT[8,:])), 8:$(sum(errGuessT[9,:])), 9:$(sum(errGuessT[10,:]))")
	println("Test Set Error Rate = $(errRateT)")
	println()
return layersK,kernels,kernBias,ins,layersN, layerEnterHL, layersHL, layerLastHL, A, target, A2, target2, width2, height2, flatSize, errCurrT, errAnsT, errGuessT, errRateT, errHist, trainCount;
end


function reconstruct(filename)
	layersK = h5read(filename, "layersK")
	
	kernels = Vector{Array{Float32}}()
	kernBias = Vector{Array{Float32}}()
	ins = Vector{Array{Float32}}()
	
	for l = 1:size(layersK)[1]
	push!(kernels,h5read(filename, "kernels$(l)"))
	push!(kernBias,h5read(filename, "kernBias$(l)"))
	push!(ins,h5read(filename, "ins$(l)"))
	end
	
	layersN = h5read(filename, "layersN")
	layerEnterHL = h5read(filename, "layerEnterHL")
	layersHL = h5read(filename, "layersHL")
	layerLastHL = h5read(filename, "layerLastHL")

	A = h5read(filename, "A")
	target = h5read(filename, "target")
	A2 = h5read(filename, "A2")
	target2 = h5read(filename, "target2")
	width = h5read(filename, "width")
	height = h5read(filename, "height")
	flatSize = h5read(filename, "flatSize")
	errCurrT = h5read(filename, "errCurrT")
	errAnsT = h5read(filename, "errAnsT")
	errGuessT = h5read(filename, "errGuessT")
	errRateT = h5read(filename, "errRateT")
	errHist = h5read(filename, "errHist")
	trainCount = h5read(filename, "trainCount")
	
	return layersK,kernels,kernBias,ins,layersN, layerEnterHL, layersHL, layerLastHL, A, target, A2, target2, width, height, flatSize, errCurrT, errAnsT, errGuessT, errRateT, errHist, trainCount;
end

#layersK = [3 3 32; 3 3 64; 0 2 2; 3 3 128; 0 2 2]
#layersK = [5 5 32; 0 2 2; 5 5 64]
#layersK = [3 3 32;3 3 64;0 2 2;3 3 128]

CNN = Vector{Array{Int64}}()
NN = Vector{Array{Int64}}()
push!(CNN,[])
push!(NN,[4096,2])
push!(CNN,[])
push!(NN,[4096,3])
push!(CNN,[])
push!(NN,[4096,4])
push!(CNN,[])
push!(NN,[4096,5])
push!(CNN,[])
push!(NN,[4096,6])
push!(CNN,[3 3 32; 3 3 64])
push!(NN,[4096,2])
push!(CNN,[3 3 32; 3 3 64; 0 2 2])
push!(NN,[4096,2])
push!(CNN,[3 3 32; 3 3 64; 0 2 2])
push!(NN,[4096,3])
push!(CNN,[5 5 32; 0 2 2; 5 5 64])
push!(NN,[4096,2])
push!(CNN,[3 3 32; 3 3 64; 0 2 2; 3 3 128])
push!(NN,[4096,2])
#pouts = FinalProj(CNN[5], NN[5]);
#pouts = reconstruct("Ngo_FinalProjOutput27.h5")


for c = 1:length(CNN)
	@time outs = FinalProj(CNN[c], NN[c]);

	filename = "Ngo_FinalProjOutput3$(c).h5"

	h5open(filename, "w") do file
		write(file, "layersK", outs[1])
		for l = 1:size(outs[1])[1]
			write(file, "kernels$(l)", outs[2][l])
			write(file, "kernBias$(l)", outs[3][l])
			write(file, "ins$(l)", outs[4][l])
		end
		write(file, "layersN", outs[5])
		write(file, "layerEnterHL", outs[6])
		write(file, "layersHL", outs[7])
		write(file, "layerLastHL", outs[8])
		write(file, "A", outs[9])
		write(file, "target", outs[10])
		write(file, "A2", outs[11])
		write(file, "target2", outs[12])
		write(file, "width", outs[13])
		write(file, "height", outs[14])
		write(file, "flatSize", outs[15])
		write(file, "errCurrT", outs[16])
		write(file, "errAnsT", outs[17])
		write(file, "errGuessT", outs[18])
		write(file, "errRateT", outs[19])
		write(file, "errHist", outs[20])
		write(file, "trainCount", outs[21])
	end
end

outs1 = reconstruct("Ngo_FinalProjOutput31.h5")#760 iters
outs2 = reconstruct("Ngo_FinalProjOutput32.h5")#29961.53 secs
outs3 = reconstruct("Ngo_FinalProjOutput33.h5")
